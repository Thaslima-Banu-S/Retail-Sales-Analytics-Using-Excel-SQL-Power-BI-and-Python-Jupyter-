CREATE database Retail_sales;
use retail_Sales;

alter table retail_sales.staffs
add constraint fk_staff_id
foreign key (store_id) references stores(store_id);

alter table retail_sales.staffs
add constraint fk_manager
foreign key (manager_id) references staffs(staff_id);

set sql_safe_updates=0;

create table orders(
order_id int,
customer_id int,
order_status varchar(20),
order_Date varchar(20),
required_Date varchar(20),
shipped_Date varchar(20),
store_id int,
staff_id int
);
select * from retail_sales.orders;

UPDATE orders
SET order_date = STR_TO_DATE(order_date, '%d-%m-%Y');

UPDATE orders
SET required_date = STR_TO_DATE(required_date, '%d-%m-%Y');

ALTER TABLE orders MODIFY shipped_date VARCHAR(20);

UPDATE orders
SET shipped_date = STR_TO_DATE(shipped_date, '%d-%m-%Y');

UPDATE orders
SET shipped_date = NULL
WHERE  shipped_date = 'Not yet shipped';

ALTER TABLE orders MODIFY order_date DATE;
ALTER TABLE orders MODIFY required_date DATE;
ALTER TABLE orders MODIFY shipped_date DATE;

ALTER TABLE orders
ADD PRIMARY KEY (order_id);

alter table retail_sales.orders
add constraint fk_orders_customer
foreign key (customer_id)
references customers(customer_id);

alter table retail_sales.orders
add constraint fk_orders_store
foreign key (store_id)
references stores(store_id);

alter table retail_sales.orders
add constraint fk_orders_staff
foreign key(staff_id)
references staffs(staff_id);

alter table order_items
add constraint fk_items_order
foreign key (order_id)
references orders(order_id);

alter table order_items
add constraint fk_items_product
foreign key(product_id)
references products(product_id);

-- Q3
select o.order_id, o.order_date,
p.product_name,
oi.quantity, oi.discount, oi.revenue
from orders o 
inner join order_items oi on o.order_id = oi.order_id
inner join products p on oi.product_id = p.product_id;

-- Q4
select o.store_id, 
sum(oi.revenue) as Total_Sales
from orders o 
inner join order_items oi on o.order_id = oi.order_id group by o.store_id;

-- Q5
select p.product_name,
sum(oi.quantity) as Total_Sold
from order_items oi
inner join products p on oi.product_id = p.product_id group by p.product_id 
order by Total_Sold desc limit 5;

-- Q6
select c.customer_id,
concat(c.first_name,' ', c.last_name) as Customer_Name,
count(distinct o.order_id) as Total_Orders,
sum(oi.quantity) as Total_Items,
sum(oi.revenue) as Total_Revenue
from customers c
left join orders o on c.customer_id = o.customer_id
left join order_items oi on o.order_id = oi.order_id
group by c.customer_id;

-- Q7
select c.customer_id,
sum(oi.revenue) as Total_Revenue,
case 
when sum(oi.revenue) < 5000 then "Low"
when sum(oi.revenue) between 5000 and 20000 then "Medium"
else "High" 
end as Segment
from customers c 
inner join orders o on c.customer_id = o.customer_id
inner join order_items oi on o.order_id = oi.order_id
group by c.customer_id;

-- Q8
select s.staff_id,
concat(s.first_name,' ',s.last_name) as Staff_name,
sum(oi.revenue) as Total_Revenue
from staffs s 
inner join orders o on s.staff_id = o.staff_id
inner join order_items oi on o.order_id = oi.order_id
group by s.staff_id order by Total_Revenue desc;

-- Q9
select product_id, store_id, 
quantity as Remaining_stock
from stocks 
where quantity < 10;

-- Q10
Create table retail_sales.customer_segments (
customer_id varchar(100),Recency INT,Frequency INT,Monetary DECIMAL(10,2),Segment VARCHAR(50));
select * from retail_sales.customer_Segments;


